public enum Tipo {
    AGUA,
    FUEGO,
    PLANTA,
    DRAGON
}
