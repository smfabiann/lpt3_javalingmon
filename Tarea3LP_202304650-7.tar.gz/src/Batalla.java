public interface Batalla {
    public Javaling elgirJavalingActivo();
}
